# Django React-Admin Provider

Dynamic backend for React-Admin with DRF, RBAC, nested writes, and model/schema introspection.